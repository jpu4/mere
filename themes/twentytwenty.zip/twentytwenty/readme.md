# TwentyTwenty
> A mere theme.

Origin: [Start Bootstrap - Modern Business](https://startbootstrap.com/templates/modern-business/)
GitHub: <https://github.com/BlackrockDigital/startbootstrap-modern-business>

```
License: MIT License
Released: Sep 26, 2013
Bootstrap Version: 4.3.1
```

https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css
https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js
https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js
https://code.jquery.com/jquery-3.4.1.min.js